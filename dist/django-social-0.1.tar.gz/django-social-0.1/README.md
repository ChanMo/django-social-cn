# Django Social APP

[*] 微信APP
[*] 微信小程序
[*] 微信服务号
[*] 抖音小程序
[*] QQ开放平台
