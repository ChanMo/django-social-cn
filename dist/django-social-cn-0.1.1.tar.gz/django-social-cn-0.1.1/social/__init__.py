default_app_config = 'social.apps.SocialConfig'
